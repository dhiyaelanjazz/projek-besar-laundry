<?php 
include"proses.php";

$username = $_POST['username'];
$password = $_POST['password'];
$status=$_POST['status'];
$sql=mysqli_query($conn, "insert into petugas values(' ','$username','$password','$status')");
header("location:login.php");
?>
?>
